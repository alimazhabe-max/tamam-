"""
تاریخ و زمان — همه ابزارها (۱ تا ۱۰ + شمارش‌معکوس سفارشی)
"""
import re
from datetime import datetime, date, timedelta
import jdatetime
from hijri_converter import Gregorian, Hijri
import pytz
from bot.config import config
from bot.utils.events import shamsi_events, hijri_events

tehran_tz = pytz.timezone(config.TIMEZONE)

PERSIAN_MONTHS = {
    1: "فروردین", 2: "اردیبهشت", 3: "خرداد", 4: "تیر",
    5: "مرداد", 6: "شهریور", 7: "مهر", 8: "آبان",
    9: "آذر", 10: "دی", 11: "بهمن", 12: "اسفند"
}
PERSIAN_MONTHS_REV = {v: k for k, v in PERSIAN_MONTHS.items()}
PERSIAN_WEEKDAYS = {
    0: "شنبه", 1: "یکشنبه", 2: "دوشنبه", 3: "سه‌شنبه",
    4: "چهارشنبه", 5: "پنجشنبه", 6: "جمعه"
}
GREGORIAN_MONTHS = {
    1: "January", 2: "February", 3: "March", 4: "April",
    5: "May", 6: "June", 7: "July", 8: "August",
    9: "September", 10: "October", 11: "November", 12: "December"
}
HIJRI_MONTHS = {
    1: "محرم", 2: "صفر", 3: "ربیع‌الاول", 4: "ربیع‌الثانی",
    5: "جمادی‌الاول", 6: "جمادی‌الثانی", 7: "رجب", 8: "شعبان",
    9: "رمضان", 10: "شوال", 11: "ذی‌قعده", 12: "ذی‌الحجه"
}
HIJRI_MONTHS_REV = {v: k for k, v in HIJRI_MONTHS.items()}
HIJRI_MONTHS_REV.update({
    "ربیع الاول": 3, "ربیع اول": 3, "ربیع الثانی": 4, "ربیع دوم": 4,
    "جمادی الاول": 5, "جمادی اول": 5, "جمادی الثانی": 6, "جمادی دوم": 6,
    "ذیقعده": 11, "ذی قعده": 11, "ذیالحجه": 12, "ذی الحجه": 12, "ذیحجه": 12,
})

ZODIAC = [
    (1, 1, 1, 20, "♑ بزغاله (جدی)"), (1, 21, 2, 19, "♒ دلو"),
    (2, 20, 3, 20, "♓ حوت"), (3, 21, 4, 20, "♈ حمل"),
    (4, 21, 5, 21, "♉ ثور"), (5, 22, 6, 21, "♊ جوزا"),
    (6, 22, 7, 22, "♋ سرطان"), (7, 23, 8, 22, "♌ اسد"),
    (8, 23, 9, 22, "♍ سنبله"), (9, 23, 10, 22, "♎ میزان"),
    (10, 23, 11, 21, "♏ عقرب"), (11, 22, 12, 21, "♐ قوس"),
    (12, 22, 12, 31, "♑ بزغاله (جدی)"),
]
CHINESE_ANIMALS = [
    "🐀 موش", "🐂 گاو", "🐅 ببر", "🐇 خرگوش", "🐉 اژدها", "🐍 مار",
    "🐎 اسب", "🐐 بز", "🐒 میمون", "🐓 خروس", "🐕 سگ", "🐖 خوک",
]

WORLD_CITIES = {
    "تهران": "Asia/Tehran", "دبی": "Asia/Dubai", "استانبول": "Europe/Istanbul",
    "لندن": "Europe/London", "پاریس": "Europe/Paris", "نیویورک": "America/New_York",
    "لس‌آنجلس": "America/Los_Angeles", "توکیو": "Asia/Tokyo", "پکن": "Asia/Shanghai",
    "مسکو": "Europe/Moscow", "سیدنی": "Australia/Sydney", "ریاض": "Asia/Riyadh",
}


def pn(num):
    return str(num).translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))


def _norm(text: str) -> str:
    fa, ar, en = "۰۱۲۳۴۵۶۷۸۹", "٠١٢٣٤٥٦٧٨٩", "0123456789"
    text = text.translate(str.maketrans(fa + ar, en + en))
    text = text.replace("ـ", "-").replace("٫", ".")
    return re.sub(r"[\/\-\.]", "/", text.strip())


def parse_shamsi(text: str):
    text = text.strip()
    n = _norm(text)
    m = re.match(r"^(\d{3,4})\s*/\s*(\d{1,2})\s*/\s*(\d{1,2})(?:\s+(\d{1,2}):(\d{1,2}))?$", n)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        h = int(m.group(4)) if m.group(4) else 0
        mi = int(m.group(5)) if m.group(5) else 0
        if 1200 <= y <= 1500:
            return (y, mo, d, h, mi)
    for name, num in PERSIAN_MONTHS_REV.items():
        if name in text:
            nums = re.findall(r"\d+", n)
            if len(nums) >= 2:
                day, year = int(nums[0]), int(nums[-1])
                if 1200 <= year <= 1500:
                    return (year, num, day, 0, 0)
            break
    return None


def parse_any_date(text: str):
    n = _norm(text.strip())
    m = re.match(r"^(\d{3,4})\s*/\s*(\d{1,2})\s*/\s*(\d{1,2})$", n)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1200 <= y <= 1500:
            return ("shamsi", y, mo, d)
        if 1800 <= y <= 2100:
            return ("gregorian", y, mo, d)
        if 1300 <= y <= 1600:
            return ("hijri", y, mo, d)
    for name, num in PERSIAN_MONTHS_REV.items():
        if name in text:
            nums = re.findall(r"\d+", n)
            if len(nums) >= 2:
                return ("shamsi", int(nums[-1]), num, int(nums[0]))
    for name, num in HIJRI_MONTHS_REV.items():
        if name in text:
            nums = re.findall(r"\d+", n)
            if len(nums) >= 2:
                return ("hijri", int(nums[-1]), num, int(nums[0]))
    return None


def _g2h(g: date) -> dict:
    try:
        adj = g - timedelta(days=1)
        h = Gregorian(adj.year, adj.month, adj.day).to_hijri()
        return {"day": h.day, "month": h.month, "month_name": HIJRI_MONTHS.get(h.month, str(h.month)), "year": h.year}
    except Exception:
        return {"day": 0, "month": 0, "month_name": "—", "year": 0}


# ── ۱. روزشمار تولد ──
def birthday_countdown(y, m, d) -> str:
    try:
        today = jdatetime.datetime.now(tehran_tz).date()
        try:
            this_bd = jdatetime.date(today.year, m, d)
        except ValueError:
            this_bd = jdatetime.date(today.year, m, d - 1)
        if this_bd >= today:
            next_bd, next_age = this_bd, today.year - y
        else:
            try:
                next_bd = jdatetime.date(today.year + 1, m, d)
            except ValueError:
                next_bd = jdatetime.date(today.year + 1, m, d - 1)
            next_age = today.year - y + 1
        days_left = (next_bd - today).days
        cur_age = today.year - y - (0 if (today.month, today.day) >= (m, d) else 1)
        status = "🎉 **امروز تولد شماست!**" if days_left == 0 else f"⏳ **{pn(days_left)} روز** تا تولد بعدی"
        return (
            f"🎂 **روزشمار تولد**\n\n"
            f"📅 تولد: {pn(d)} {PERSIAN_MONTHS[m]} {pn(y)}\n"
            f"🗓 سن فعلی: {pn(cur_age)} سال\n\n{status}\n"
            f"🎈 {pn(next_bd.day)} {PERSIAN_MONTHS[next_bd.month]} {pn(next_bd.year)} → {pn(next_age)} ساله"
        )
    except Exception:
        return "❌ تاریخ نامعتبر.\nمثال: `1375/03/15`"


# ── ۲. برج + حیوان ──
def zodiac_animal(y, m, d) -> str:
    try:
        j = jdatetime.date(y, m, d)
        g = j.togregorian()
        zodiac = "نامشخص"
        for m1, d1, m2, d2, name in ZODIAC:
            if (g.month == m1 and g.day >= d1) or (g.month == m2 and g.day <= d2):
                zodiac = name
                break
        animal = CHINESE_ANIMALS[(y - 1309) % 12]
        return (
            f"♈ **برج و حیوان سال**\n\n"
            f"📅 {pn(d)} {PERSIAN_MONTHS[m]} {pn(y)}\n"
            f"📆 {g.day} {GREGORIAN_MONTHS[g.month]} {g.year}\n\n"
            f"✨ برج فلکی: {zodiac}\n🐾 حیوان سال: {animal}"
        )
    except Exception:
        return "❌ تاریخ نامعتبر.\nمثال: `1375/03/15`"


# ── ۳. سن قمری + تکلیف ──
def lunar_age(y, m, d) -> str:
    try:
        birth_g = jdatetime.date(y, m, d).togregorian()
        hb = _g2h(birth_g)
        hn = _g2h(datetime.now(tehran_tz).date())
        hy = hn["year"] - hb["year"]
        hm = hn["month"] - hb["month"]
        hd = hn["day"] - hb["day"]
        if hd < 0:
            hm -= 1
            hd += 29
        if hm < 0:
            hy -= 1
            hm += 12

        def taklif(add):
            try:
                h = Hijri(hb["year"] + add, hb["month"], min(hb["day"], 28))
                g = h.to_gregorian()
                j = jdatetime.date.fromgregorian(date=date(g.year, g.month, g.day))
                return f"{pn(j.day)} {PERSIAN_MONTHS[j.month]} {pn(j.year)}"
            except Exception:
                return "—"

        return (
            f"🌙 **سن قمری و سن تکلیف**\n\n"
            f"📅 شمسی: {pn(d)} {PERSIAN_MONTHS[m]} {pn(y)}\n"
            f"🌙 قمری: {pn(hb['day'])} {hb['month_name']} {pn(hb['year'])}\n\n"
            f"🗓 سن قمری: {pn(hy)} سال و {pn(hm)} ماه و {pn(hd)} روز\n\n"
            f"👧 سن تکلیف دختران (۹ق): {taklif(9)}\n"
            f"👦 سن تکلیف پسران (۱۵ق): {taklif(15)}"
        )
    except Exception:
        return "❌ تاریخ نامعتبر.\nمثال: `1375/03/15`"


# ── ۴. اختلاف دو تاریخ ──
def date_diff(y1, m1, d1, y2, m2, d2) -> str:
    try:
        a = jdatetime.date(y1, m1, d1)
        b = jdatetime.date(y2, m2, d2)
        if a > b:
            a, b = b, a
            y1, m1, d1, y2, m2, d2 = y2, m2, d2, y1, m1, d1
        total = (b - a).days
        years = b.year - a.year
        months = b.month - a.month
        days = b.day - a.day
        if days < 0:
            months -= 1
            pm = b.month - 1 if b.month > 1 else 12
            py = b.year if b.month > 1 else b.year - 1
            days += jdatetime.date(py, pm, 1).daysinmonth
        if months < 0:
            years -= 1
            months += 12
        return (
            f"📅 **اختلاف دو تاریخ**\n\n"
            f"از: {pn(d1)} {PERSIAN_MONTHS[m1]} {pn(y1)}\n"
            f"تا: {pn(d2)} {PERSIAN_MONTHS[m2]} {pn(y2)}\n\n"
            f"🗓 {pn(years)} سال و {pn(months)} ماه و {pn(days)} روز\n"
            f"📆 مجموع: {pn(f'{total:,}')} روز ≈ {pn(total // 7)} هفته"
        )
    except Exception:
        return "❌ فرمت: `1375/03/15 1403/05/18`"


def parse_two_dates(text: str):
    matches = re.findall(r"(\d{3,4})\s*/\s*(\d{1,2})\s*/\s*(\d{1,2})", _norm(text))
    if len(matches) >= 2:
        a = tuple(int(x) for x in matches[0])
        b = tuple(int(x) for x in matches[1])
        if 1200 <= a[0] <= 1500 and 1200 <= b[0] <= 1500:
            return a, b
    return None


# ── ۵. اختلاف سن دو نفر ──
def age_diff(y1, m1, d1, y2, m2, d2) -> str:
    return "👥 **اختلاف سن دو نفر**\n\n" + date_diff(y1, m1, d1, y2, m2, d2).replace("اختلاف دو تاریخ", "اختلاف سن")


# ── ۶. تبدیل تاریخ با روز هفته ──
def convert_with_weekday(kind, y, m, d) -> str:
    try:
        if kind == "shamsi":
            j = jdatetime.date(y, m, d)
            g = j.togregorian()
            h = _g2h(g)
        elif kind == "gregorian":
            g = date(y, m, d)
            j = jdatetime.date.fromgregorian(date=g)
            h = _g2h(g)
        else:
            hh = Hijri(y, m, d)
            gg = hh.to_gregorian()
            g = date(gg.year, gg.month, gg.day)
            j = jdatetime.date.fromgregorian(date=g)
            h = {"day": d, "month": m, "month_name": HIJRI_MONTHS.get(m, str(m)), "year": y}
        wd = PERSIAN_WEEKDAYS[j.weekday()]
        return (
            f"✅ **تبدیل تاریخ**\n\n"
            f"📅 شمسی: {wd} {pn(j.day)} {PERSIAN_MONTHS[j.month]} {pn(j.year)}\n"
            f"📆 میلادی: {g.strftime('%A')} {g.day} {GREGORIAN_MONTHS[g.month]} {g.year}\n"
            f"🌙 قمری: {pn(h['day'])} {h['month_name']} {pn(h['year'])}"
        )
    except Exception:
        return "❌ تاریخ نامعتبر.\nمثال: `1403/05/18` یا `2024/08/09`"


# ── ۷. تقویم ماه کامل ──
def month_calendar(year=None, month=None) -> str:
    try:
        today = jdatetime.datetime.now(tehran_tz).date()
        year = year or today.year
        month = month or today.month
        first = jdatetime.date(year, month, 1)
        days_in = first.daysinmonth
        start_wd = first.weekday()  # 0=شنبه
        lines = [f"📅 **{PERSIAN_MONTHS[month]} {pn(year)}**\n", "ش ی د س چ پ ج"]
        row = ["  "] * start_wd
        for day in range(1, days_in + 1):
            mark = f"{day:2d}"
            if day == today.day and month == today.month and year == today.year:
                mark = f"[{day}]"
            row.append(f"{mark:>3}")
            if len(row) == 7:
                lines.append(" ".join(row))
                row = []
        if row:
            lines.append(" ".join(row))
        # مناسبت‌های ماه
        evs = []
        for day in range(1, days_in + 1):
            key = f"{month}-{day}"
            for e in shamsi_events.get(key, []):
                if "هیچ مناسبت" not in e:
                    evs.append(f"• {pn(day)}: {e}")
        if evs:
            lines.append("\n📌 مناسبت‌ها:")
            lines.extend(evs[:15])
        return "\n".join(lines)
    except Exception as e:
        return f"❌ خطا: {e}"


# ── ۸. مناسبت‌یاب ──
def search_events(query: str) -> str:
    q = query.strip()
    if len(q) < 2:
        return "❌ حداقل ۲ حرف بنویسید."
    results = []
    for key, evs in shamsi_events.items():
        for e in evs:
            if q in e:
                m, d = key.split("-")
                results.append(f"• {pn(d)} {PERSIAN_MONTHS[int(m)]}: {e}")
    for key, evs in hijri_events.items():
        for e in evs:
            if q in e:
                m, d = key.split("-")
                results.append(f"• {pn(d)} {HIJRI_MONTHS.get(int(m), m)} (قمری): {e}")
    if not results:
        return f"❌ مناسبتی با «{q}» پیدا نشد."
    return f"🔍 **نتایج برای «{q}»:**\n\n" + "\n".join(results[:20])


# ── ۹. شمارش‌معکوس نوروز ──
def nowruz_countdown() -> str:
    today = jdatetime.datetime.now(tehran_tz).date()
    year = today.year if (today.month, today.day) < (1, 1) else today.year + 1
    # اگر هنوز به ۱ فروردین نرسیده‌ایم
    if today.month == 1 and today.day == 1:
        return "🎉 **امروز نوروز است! سال نو مبارک**"
    target = jdatetime.date(today.year + (0 if today.month < 1 or (today.month == 1 and today.day == 1) else 1), 1, 1)
    if today >= jdatetime.date(today.year, 1, 1) and not (today.month == 1 and today.day == 1):
        target = jdatetime.date(today.year + 1, 1, 1)
    days = (target - today).days
    return (
        f"🌸 **شمارش‌معکوس نوروز**\n\n"
        f"⏳ {pn(days)} روز تا ۱ فروردین {pn(target.year)}\n"
        f"📅 تحویل سال: ۱ فروردین {pn(target.year)}"
    )


# ── ۱۰. ساعت جهانی ──
def world_clock() -> str:
    now_utc = datetime.now(pytz.UTC)
    lines = ["🌍 **ساعت جهانی**\n"]
    for name, tz_name in WORLD_CITIES.items():
        tz = pytz.timezone(tz_name)
        local = now_utc.astimezone(tz)
        lines.append(f"• {name}: {local.strftime('%H:%M')} ({local.strftime('%d/%m')})")
    return "\n".join(lines)


# ── شمارش‌معکوس سفارشی ──
def custom_countdown(y, m, d, label="رویداد") -> str:
    try:
        today = jdatetime.datetime.now(tehran_tz).date()
        target = jdatetime.date(y, m, d)
        delta = (target - today).days
        if delta > 0:
            return f"⏳ **شمارش‌معکوس: {label}**\n\n{pn(delta)} روز مانده\n📅 {pn(d)} {PERSIAN_MONTHS[m]} {pn(y)}"
        if delta == 0:
            return f"🎉 **امروز همان روز است: {label}**"
        return f"📅 **{label}** {pn(abs(delta))} روز پیش بوده است."
    except Exception:
        return "❌ تاریخ نامعتبر.\nمثال: `1405/01/01 نوروز`"


def parse_countdown(text: str):
    p = parse_shamsi(text)
    if not p:
        # تاریخ + برچسب
        n = _norm(text)
        m = re.search(r"(\d{3,4})\s*/\s*(\d{1,2})\s*/\s*(\d{1,2})", n)
        if m:
            y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
            label = re.sub(r"\d{3,4}\s*[/\-\.]\s*\d{1,2}\s*[/\-\.]\s*\d{1,2}", "", text).strip() or "رویداد"
            return (y, mo, d, label)
        return None
    y, m, d, _, _ = p
    label = re.sub(r"\d{3,4}\s*[/\-\.]\s*\d{1,2}\s*[/\-\.]\s*\d{1,2}", "", text).strip() or "رویداد"
    return (y, m, d, label)
